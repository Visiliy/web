import pygame

a = []
with open('map.txt', 'r', encoding='utf-8') as f:
    for i in f:
        a.append(list(map(int, i.split())))
    
pygame.init()
pygame.display.set_caption('Перемещение героя')
size = width, height = 500, 500
clock = pygame.time.Clock()
screen = pygame.display.set_mode(size)

mario = pygame.image.load('data/mar.png').convert_alpha()
box = pygame.image.load('data/box.png').convert_alpha()
grass = pygame.image.load('data/grass.png').convert_alpha()
fon = pygame.image.load('data/mar.jpg').convert()

mario.set_colorkey((255, 255, 255))
box.set_colorkey((255, 255, 255))
grass.set_colorkey((255, 255, 255))

pygame.display.set_icon(fon)
fon_0 = pygame.transform.scale(fon, (500, 500))
running1 = True
running2 = False
running3 = False
v = 1
slov = {0: grass, 1: box}

m_x, m_y = 4, 4
g, h = m_x, m_y
screen.blit(mario, (50 * m_x + 13, 50 * m_y + 4))


while running1:
    screen.fill((255, 255, 255))
    screen.blit(fon, (0, 0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running1 = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            running1 = False
            running2 = True
    screen.blit(fon_0, (0, 0))
    pygame.display.flip()   


while running2:
    screen.fill((0, 0, 0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running2 = False
    for y in range(len(a)):
        for x in range(len(a[0])):
            screen.blit(slov[a[y][x]], (50 * x, 50 * y))
                        
    n = pygame.key.get_pressed()
    if n[pygame.K_RIGHT]:
        g += v
    if n[pygame.K_LEFT]:
        g -= v
    if n[pygame.K_DOWN]:
        h += v
    if n[pygame.K_UP]:
        h -= v
    if h < 10 and g < 10 and h > -1 and g > -1 and a[h][g] in [0, 2]:
        m_x, m_y = g, h
        screen.blit(mario, (50 * m_x + 13, 50 * m_y + 4))
    else:
        g, h = m_x, m_y
        screen.blit(mario, (50 * m_x + 13, 50 * m_y + 4))
    pygame.display.flip()
    clock.tick(10)
pygame.quit()